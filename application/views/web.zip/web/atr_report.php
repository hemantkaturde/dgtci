   <!--SECTION START-->
   <section>
        <div class="container com-sp pad-bot-70">
            <div class="row">
                <div class="cor about-sp">
                    <div class="ed-about-tit">
                        <div class="con-title">
                            <h2>IQAC MINUTES / ATR </h2>
                            <!-- <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p> -->
                        </div>
                    </div>
                    <div class="pg-contact">

                        <h2>IQAC MINUTES / ATR</h2>
                        <table>
                            <tr>
                              <th><B>IQAC Minutes / ATR </B></th>
                              <td><B>Download</B></td>
                            </tr>
                           
                            <tr>
                                <td>IQAC Minutes / ATR</td>
                                <td><a href="documents/minutes/11687_Minutes_atr.pdf" target="_blank" style="color: blue;">IQAC Minutes / ATR</a> <i class="fa fa-file-pdf-o" aria-hidden="true" style="color: red"></i></td>
                              </tr>
                          </table>
                          </body>
                          </html>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--SECTION END-->

    <style>
    .red_topNav 
    {
    clear: both;
    position: relative;
    z-index: 1001;
    height: 24px;
    background: url(../sites/all/themes/iist/images/red_navBg.gif) repeat-x 0 100% #2e7464;
    }

    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }
    
    td, th {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }
    
    tr:nth-child(even) {
      background-color: #dddddd;
    }
</style>