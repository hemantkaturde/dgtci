<!--SECTION START-->
<section>
        <div class="ed-res-bg">
		<div class="container com-sp pad-bot-50 ed-res-bg">
            <h3 style="text-align:center; margin-bottom:10px;">GALLERY</h3>
            <div class="row">
                <div class="cor about-sp h-gal ed-pho-gal">
					<ul>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo1.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo2.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo3.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo4.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo5.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo6.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo8.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo9.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo10.png" alt="">
						</li>
						<li><img class="materialboxed" data-caption="image captions" src="<?php echo base_url() ?>assets/web/images/dgt/photo11.png" alt="">
						</li>
					</ul>
                </div>
            </div>
        </div>
		</div>
    </section>
    <!--SECTION END-->