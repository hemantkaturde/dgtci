    <!--SECTION START-->
    <section>
        <div class="container com-sp pad-bot-70">
            <div class="row">
                <div class="cor about-sp">
                    <div class="ed-about-tit">
                        <div class="con-title">
                            <h2>College Executive Committee</h2>
                            <hr>
                            <!-- <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p> -->
                        </div>
                    </div>
                    <div class="pg-contact">


                        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet"
                            id="bootstrap-css">
                        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
                        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
                        <!------ Include the above in your HEAD tag ---------->

                        <!-- Team -->
                        <section id="team" class="pb-5">
                            <div class="container">
                                <h5 class="section-title h1">College Executive Committee</h5>
                                <div class="row">
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip">
                                            <div class="mainflip flip-0">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/chandrakant_rode_small.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.CHANDRAKANT MAHADEV RODE</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>PRESIDENT</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.CHANDRAKANT MAHADEV RODE</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/purshottam_mule.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.PURUSHOTTAM GOVIND MULEY</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>VICE- PRESIDENT</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.PURUSHOTTAM GOVIND MULEY</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/mangesh_deshmukh.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.MANGESH PRABHAKAR DESHMUKH</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>SECRETARY</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.MANGESH PRABHAKAR DESHMUKH</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/kausthubh dhamankar.jpg"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title"> ADV.KAUSTUBH VIDYADHAR DHAMANKAR
                                                            </h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>TREASURER</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title"> ADV.KAUSTUBH VIDYADHAR DHAMANKAR
                                                            </h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/shrinivas_vedak.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title"> DR.SHRINIVAS PRABHAKAR VEDAK</h4>
                                                            <p class="card-text">FOUNDER MEMBER</p>
                                                            <p><b>MEMBER</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title"> DR.SHRINIVAS PRABHAKAR VEDAK</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/bhalchandra_sapre.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.BHALACHANDRA BHASKAR SAPRE</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>MEMBER</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.BHALACHANDRA BHASKAR SAPRE</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/satish_vadke.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">DR.SATISH GOPINATH VADKE</h4>
                                                            <p class="card-text">FOUNDER MEMBER</p>
                                                            <p><b>Member</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">DR.SATISH GOPINATH VADKE</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/kiran_deshmukh.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.KIRAN DATTATREY DESHMUKH</h4>
                                                            <p class="card-text">FOUNDER MEMBER</p>
                                                            <p><b>Member</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.KIRAN DATTATREY DESHMUKH</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/mahendra_kajbaje.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.MAHENDRA BALKRUSHNA KAJBAJE</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>Member</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>


                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.MAHENDRA BALKRUSHNA KAJBAJE</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/dipak_kotia.png"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.DIPAK PURUSHOTTAM KOTIYA</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>Member</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.DIPAK PURUSHOTTAM KOTIYA</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->
                                    <!-- Team member -->
                                    <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                            <div class="mainflip">
                                                <div class="frontside">
                                                    <div class="card">
                                                        <div class="card-body text-center">
                                                            <p><img class=" img-fluid"
                                                                    src="<?php echo base_url() ?>assets/web/images/tursthi_photo/Shriram Kajbaje.jpg"
                                                                    alt="card image"></p>
                                                            <h4 class="card-title">MR.SHRIRAM YASHWANT KAJBAJE</h4>
                                                            <p class="card-text">LIFE MEMBER</p>
                                                            <p><b>Member</b></p>
                                                            <!-- <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                                            <p>D G Tatkare College,Tala</p>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="backside">
                                                    <div class="card">
                                                        <div class="card-body text-center mt-4">
                                                            <h4 class="card-title">MR.SHRIRAM YASHWANT KAJBAJE</h4>
                                                            <p class="card-text">This is basic card with image on top,
                                                                title, description and button.This is basic card with
                                                                image on top, title, description and button.This is
                                                                basic card with image on top, title, description and
                                                                button.</p>
                                                            <ul class="list-inline">
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-skype"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="list-inline-item">
                                                                    <a class="social-icon text-xs-center"
                                                                        target="_blank"
                                                                        href="https://www.fiverr.com/share/qb8D02">
                                                                        <i class="fa fa-google"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./Team member -->


                                </div>
                            </div>
                        </section>
                        <!-- Team -->


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--SECTION END-->