<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Erişim Reddedildi
            <small>Bu sayfaya giriş yetkiniz yok.</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-center">
                <img src="<?php echo base_url() ?>assets/images/access.png" alt="Access Denied Image" />
            </div>
        </div>
    </section>
</div>